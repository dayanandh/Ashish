import { Component, OnInit } from '@angular/core';
import { UserService  } from '../services/user.service';

@Component({
  selector: 'app-student-header',
  templateUrl: './student-header.component.html',
  styleUrls: ['./student-header.component.css']
})
export class StudentHeaderComponent implements OnInit {

  constructor(private service: UserService) {  }

  ngOnInit() {
  }
  logout(){
    var comfirmLogout = confirm("Are you Sure to logout!");
  if (comfirmLogout == true) {
    this.service.studentLogout();
  } 
  }
  showAllBooks(){
    this.service.navigateStudentShowAllBooks();
  }
  myBooks(){
    this.service.navigateStudentMyBooks();
  }

  requestedBooks(){
    this.service.navigateStudentRequestedBooks();
  }
}
