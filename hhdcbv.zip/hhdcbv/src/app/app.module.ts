import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ShowAllFlightComponent } from './show-all-flights/show-all-flightss.component';
import { HttpClientModule } from '@angular/common/http';
import { UserMyBookingsComponent } from './user-my-bookings/user-my-bookings.component';
import { StudentHeaderComponent } from './student-header/student-header.component';
import { StudentRequestedBooksComponent } from './student-requested-books/student-requested-books.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ShowAllFlightComponent,
    UserMyBookingsComponent,
    StudentHeaderComponent,
    StudentRequestedBooksComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
