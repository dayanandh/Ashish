import { Component, OnInit } from '@angular/core';
import { UserService  } from '../services/user.service';
import { Router } from '@angular/router';
import { StudentHeaderComponent } from '../student-header/student-header.component';
import {FlightInformation} from '../model/flightinformation';


@Component({
  selector: 'app-show-all-books',
  templateUrl: './show-all-books.component.html',
  styleUrls: ['./show-all-books.component.css']
})
export class ShowAllFlightComponent implements OnInit {
 loginstatus : boolean  = false;
 flightList : FlightInformation[] ;
  constructor(private service: UserService, private route: Router) { }

  ngOnInit() {

    this.service.getAllFlights().subscribe((data)=>{
      // data.forEach((d)=>{alert(d)})
      this.flightList = data;
    });
    this.flightList.forEach((data)=> {
      alert(JSON.stringify(data))
    })
    this.loginstatus = this.service.getLoginStatus()
    if(this.loginstatus==false)
    {
      this.route.navigate([''])
    }
  }

  requestBook(flight : FlightInformation){
    alert(JSON.stringify(flight));
  }

}
