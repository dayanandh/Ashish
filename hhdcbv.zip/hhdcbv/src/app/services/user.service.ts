import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../model/login';
import { Register } from '../model/Register'
import { Users} from '../model/users';
import {FlightInformation } from '../model/flightinformation';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import {BookTransaction} from '../model/bookTransaction'
// import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
)
export class UserService {
  apiURL: string = 'http://localhost:8086/LibrarySpringAngular/rest/';



  loggedInUser: Users ;
  loginstatus: boolean = false;

  

  
  constructor(private route: Router, private http: HttpClient) { }//,private http: HttpClient

  loginAsUser(login: Login) {
    var loginJson = JSON.stringify(login);
    // this.loginstatus = true;
    // this.route.navigate(['/books']);
    // alert(JSON.stringify(login) + loginJson + '{ "userName": "atanu",   "password": "12345",  "authority": "student" }')

    this.http.post(`${this.apiURL}/studentLogin`, login).subscribe((data: Users) => {
      if (data.login != null) {
        this.loginstatus = true;
        this.loggedInUser = data;
        // alert(this.loggedInStudent);
        this.route.navigate(['/books']);
      }
      else {
        alert('Wrong username or pasword')
      }

    })
  }

  
  getLoginStatus() {
    return this.loginstatus;
  }
  studentLogout() {
    this.loginstatus = false;
    this.route.navigate(['/login']);
  }

  navigateStudentShowAllBooks() {
    this.route.navigate(['/books'])
  }
  navigateStudentMyBooks() {
    this.route.navigate(['/student/books'])
  }
  navigateStudentRequestedBooks(){
    this.route.navigate(['/student/bookRequests'])
  }

  getAllFlights(){
  //  var  booklist : Book[]  ;
    return this.http.get<FlightInformation[]>(`${this.apiURL}/book/getAll`)//.subscribe((data: Book[]) => {
      // booklist =  data;
      // data.forEach((data)=>{console.log(data)});
    // })
    //  return booklist;
  }

  getAllBookings(){
    //  var  booklist : Book[]  ;
      return this.http.get<BookTransaction[]>(`${this.apiURL}/book/getAll`)//.subscribe((data: Book[]) => {
        // booklist =  data;
        // data.forEach((data)=>{console.log(data)});
      // })
      //  return booklist;
    }

    registerUser(){
      this.http.put<Register>(`${this.apiURL}/book/getAll`)
    }
}
