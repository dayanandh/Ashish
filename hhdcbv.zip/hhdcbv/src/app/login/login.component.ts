import { Component, OnInit } from '@angular/core';
import { Login  } from '../model/login';
import {FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import{UserService} from '../services/user.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login : Login;
  loginForm : FormGroup;
  constructor(private fb: FormBuilder,private service: UserService,private route: Router) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      userName : new FormControl('',[Validators.required]),
      password : new FormControl('',Validators.required),
      authority : new FormControl()

    })
  }

  checklogin()
  {
    this.login = this.loginForm.getRawValue();
    this.login.authority = 'user';
    // alert(JSON.stringify(this.login))
   this.service.loginAsUser(this.login);
  }
  

}
