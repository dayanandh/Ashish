import { Component, OnInit } from '@angular/core';
import { UserService  } from '../services/user.service';
import {BookTransaction} from '../model/bookTransaction';

@Component({
  selector: 'app-student-my-books',
  templateUrl: './student-my-books.component.html',
  styleUrls: ['./student-my-books.component.css']
})
export class UserMyBookingsComponent implements OnInit {
  bookTransactionList : BookTransaction[];
  constructor(private service: UserService) { }

  ngOnInit() {
    this.service.getAllBookings().subscribe((data :BookTransaction[])=> {
      this.bookTransactionList = data;
    })
  }

}
