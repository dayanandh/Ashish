import { Component, OnInit } from '@angular/core';
import { Register  } from '../model/Register';
import {FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import{UserService} from '../services/user.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  register : Register;
  registerForm : FormGroup;
  constructor(private fb: FormBuilder,private service: UserService,private route: Router) { }

  ngOnInit() {
    this.registerForm = this.fb.group({
      userId : new FormControl('',[Validators.required]),
      name : new FormControl('',Validators.required),
      eMail : new FormControl(),
      mobileNo : new FormControl(),
      password : new FormControl()

    })
  }

  checkregister()
  {
    this.register = this.registerForm.getRawValue();
    // alert(JSON.stringify(this.login))
   this.service.registerUser(this.register);
  }
  

}
