import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowAllFlightComponent } from './show-all-flights/show-all-flightss.component';
import { LoginComponent } from "./login/login.component";
import { StudentRequestedBooksComponent } from './student-requested-books/student-requested-books.component';
import { UserMyBookingsComponent } from './user-my-bookings/user-my-bookings.component';
const routes: Routes = [
  
  {path:'',redirectTo:'/login',pathMatch:'full'},
  {path:'login',component:LoginComponent,pathMatch:'full'},
  {path:'books',component:ShowAllFlightComponent,pathMatch:'full'},
  {path:'student/books',component:UserMyBookingsComponent,pathMatch:'full'},
  {path:'student/bookRequests',component:StudentRequestedBooksComponent,pathMatch:'full'},
  {path:'**',redirectTo:'/login',pathMatch:'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
