export interface Register {
    userId: String;
    password: String;
    name: String;
    eMail: String;
    mobileNo: String;
}