import {Login} from './login'
import {Register} from './Register'
export interface Users {
    userId: String;
    password: String;
    name: String;
    eMail: String;
    mobileNo: String;  
    login : Login;
    register : Register;
}