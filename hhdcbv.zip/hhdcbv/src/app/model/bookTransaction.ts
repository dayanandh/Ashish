
import { FlightInformation } from './flightinformation';
import { Users } from './users';
export interface BookTransaction {
    bookingId: number;	
    flightId:FlightInformation;
    email: Users;	
    noOfPassenger: number;	
    classType: String;	
    totalFare: number;
    seatNo: number;	
    creditCard: String;
    SourceCity: FlightInformation;	
    Destiny: FlightInformation;
}
