export interface Login {
	userId : string;
    password : string;
	authority : string;
}