import { Component, OnInit } from '@angular/core';
import { UserService  } from '../services/user.service';
import {BookTransaction} from '../model/bookTransaction';

@Component({
  selector: 'app-student-requested-books',
  templateUrl: './student-requested-books.component.html',
  styleUrls: ['./student-requested-books.component.css']
})
export class StudentRequestedBooksComponent implements OnInit {
  bookTransactionList : BookTransaction[];
  constructor(private service: UserService) { }

  ngOnInit() {
    this.service.getrequestedBooks().subscribe((data :BookTransaction[])=> {
      this.bookTransactionList = data;
    })
  }

}
