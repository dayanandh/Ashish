export class Users {
    userId: String;
    password: String;
    name: String;
    eMail: String;
    mobileNo: String;  
}