import { Injectable }      from '@angular/core';

import {Http,Response,Headers, RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"
import "rxjs/add/operator/catch"
import { Users } from './user';

//import "rxjs/add/operator/throw"
@Injectable()
export class UserService{
   
    constructor(private http:Http) {}
  //For All Application check your your REST URI-PORT & Path   
    //GET ALL -with Spring JPA-http://localhost:9090/SpringWithJpa/rest/employee
    getUser():Observable<Users[]> 
    { return  this.http.get("http://localhost:8086/AirlineResrvation/rest/checkLogin").
            map((response:Response)=><Users[]>response.json())
            .catch(this.handleError1);
        }
        handleError1(error: Response){
            console.error(error);
            return Observable.throw(error);
        }

        handleError2(error: Response){
            console.error(error);
            return Observable.throw(error);
        }
    }