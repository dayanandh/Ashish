import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`<div><ul>
                            <li><a routerLink="getdata">Show ALL</a></li>
                            <li><a routerLink="postdata">ADD Flight</a></li>
                            <li><a routerLink="search">Search & Update Flight</a></li>
                            
                          </ul>
                      <router-outlet></router-outlet>  </div>`
  
})
export class AppComponent { name = 'Welcome Angular 2'; }
