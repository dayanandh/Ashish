import { Component } from '@angular/core';
import { UserService} from './app.login.service';
import { Users } from './user';
import {Router} from '@angular/router'

@Component({
  selector: 'login-app',
  templateUrl: `./app.logincomponent.html`,
  styleUrls: ['./app.logincomponent.css'],
  providers: [UserService]
})

export class LoginComponent {
  constructor(private service: UserService,private router:Router) {
  }

  userId: string;
  password: string;
  model:any={};
  
  onSubmit(): void {
    this.service.view1(this.userId).subscribe((userData:Users[]) => this.model = userData,
      (error) => {
         console.error(error);
      },
      ()=>{ this.router.navigate(['homes']);}
    );
  }
 
}
