import { Injectable }      from '@angular/core';

import {Http,Response,Headers, RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"
import "rxjs/add/operator/catch"
import { BookingInformation } from './bookinginformation';

//import "rxjs/add/operator/throw"
@Injectable()
export class BookingInformationService{
   
    constructor(private http:Http) {}
  //For All Application check your your REST URI-PORT & Path   
    //GET ALL -with Spring JPA-http://localhost:9090/SpringWithJpa/rest/employee
    viewAllBookings():Observable<BookingInformation[]> 
    { return  this.http.get("http://localhost:8086/AirlineResrvation/rest/bookinginformation").
            map((response:Response)=><BookingInformation[]>response.json())
            .catch(this.handleError1);
        }
        handleError1(error: Response){
            console.error(error);
            return Observable.throw(error);
        }

        handleError2(error: Response){
            console.error(error);
            return Observable.throw(error);
        }
    
         //add data--with Spring JPA-http://localhost:8086/AirlineResrvation/rest/flightinformation/create/
         addBooking(data:BookingInformation): Observable<BookingInformation[]> {
            let empData=JSON.stringify(data);
            alert(empData);
            let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
            let options = new RequestOptions({ headers: cpHeaders });
            
            return this.http
                .post('http://localhost:8086/AirlineResrvation/rest/bookinginformation/create/',empData,options)
                .map((success => success.status))
                .catch(this.handleError1);
            }

         //delete data--with Spring JPA-http://localhost:9090/SpringWithJpa/rest/employee/delete/
         deleteBooking(data:number): Observable<BookingInformation[]> {
        console.log(data)
        return this.http
            .delete('http://localhost:8086/AirlineResrvation/rest/bookinginformation/delete/'+data)
            .map((response:Response)=><BookingInformation[]>response.json())
            .catch(this.handleError2);
        }
        handleErrorDelete(error: Response){
            console.error(error);
            return Observable.throw(error);
        }
}