import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent }  from './app.component';
import { FlightList }  from './app.flightlist';
import { BookingList }  from './app.bookingList';

import {UserService} from './app.login.service'
import { HomeComponent }  from './HomeComponent';
import { FlightSearchComponent }  from './FlightSearchComponent';
import {HttpModule} from '@angular/http';
import {Routes, RouterModule} from '@angular/router';

const appRoutes: Routes=[
                   
                     { path: '',  redirectTo:'/getdata',pathMatch: 'full'},
                     { path: 'getdata',  component: FlightList},
                     { path: 'postdata',  component: HomeComponent },
                     {path:'search',component:FlightSearchComponent}
                     
                      ];
@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(appRoutes) ],
  declarations: [ AppComponent,FlightList,HomeComponent,FlightSearchComponent,BookingList,UserService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
