import {Component,OnInit} from '@angular/core';
import {BookingInformation} from './bookinginformation';
import {BookingInformationService} from './bookinginformation.service';


@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.bookinginformationcomponent.html',
    providers:[BookingInformationService]
})
export class BookingList implements  OnInit{
    
    bookings:BookingInformation[];
    statusmessage:string;


constructor(private flyservice:BookingInformationService) {}
ngOnInit(): void {


    this.flyservice.viewAllBookings().subscribe((bookingData)=>this.bookings=bookingData,
    (error)=>{
    this.statusmessage="Problem with service check server"
    }    
    );
 
}
//  delete(id:number):void{
//     this.flyservice.deleteBooking(id).subscribe((bookingData)=>this.bookings=bookingData,
//             (error)=>{
//                 this.statusmessage="Problem with service check server"
//                    // console.error(error);
//             }    
//             );
// } 
 
}