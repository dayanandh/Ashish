export class BookingInformation{
     bookingId: number;	
	  email: String;	
	 noOfPassenger: number;	
	  classType: String;	
	 totalFare: number;
	 seatNo: number;	
	  creditCard: String;
   SourceCity: String;	
	  Destiny: String;
}